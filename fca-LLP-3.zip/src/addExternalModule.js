-+"use strict";

const utils = require("../utils");

module.exports = function (defaultFuncs, api, ctx) {
  return function addExternalModule(moduleObj) {
    if (utils.getType(moduleObj) == "Object") {
      for (let apiName in moduleObj) {
        if (utils.getType(moduleObj[apiName]) == "Function") {
          api[apiName] = moduleObj[apiName](defaultFuncs, api, ctx);
        } else {
          throw new Error(`Mục "${apiName}" trong moduleObj phải là một hàm, không phải ${utils.getType(moduleObj[apiName])}!`);
        }
      }
    } else {
      throw new Error(`moduleObj phải là một đối tượng, không phải ${utils.getType(moduleObj)}!`);
    }
  };
};
